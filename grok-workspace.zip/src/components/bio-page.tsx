import { useEffect, useState } from "react";
import {
  ArrowUpRight,
  FileSearch,
  Globe,
  HeartHandshake,
  Instagram,
  Moon,
  Scale,
  ShieldCheck,
  Stethoscope,
  Sun,
  Users,
} from "lucide-react";

const SITE = "https://www.peritajesmedicos.cl/";
const REEL = "https://www.instagram.com/reel/DeKBLDeRHFz/";
const INSTAGRAM = "https://www.instagram.com/peritajes_medicosmaule/";

const HELP = [
  {
    title: "Pensión de invalidez",
    text: "Comisiones, AFP y actas que omiten diagnósticos, fechas o el daño real. Leemos el expediente como quien ya vio uno salir mal.",
    icon: Scale,
  },
  {
    title: "Licencias médicas",
    text: "Desvinculaciones en plena licencia, licencias impagas y la sensación de tener que demostrar que el dolor existe.",
    icon: FileSearch,
  },
  {
    title: "Negligencia médica",
    text: "Cuando faltó la lex artis: no pidieron el examen, no miraron la ficha, o el papel no coincide con lo que te operaron.",
    icon: Stethoscope,
  },
  {
    title: "Trámites que no se entienden",
    text: "Procesos judiciales, previsionales y administrativos. El informe tiene que ser claro para ti y sostenible ante quien decide.",
    icon: ShieldCheck,
  },
] as const;

const WAY = [
  {
    title: "Ética antes que el resultado",
    text: "El requisito del equipo es una ética inquebrantable. El informe dice lo que la evidencia sostiene, no lo que conviene oír.",
    icon: ShieldCheck,
  },
  {
    title: "Un equipo, no una sola voz",
    text: "Médicos de distintas disciplinas. El caso no queda en una impresión ni en una radiografía que no muestra el tejido blando.",
    icon: Users,
  },
  {
    title: "Cercanía, sin chamullo",
    text: "Acompañamiento personal y humano. Si llegas con rabia, se entiende. También se entendió desde este lado.",
    icon: HeartHandshake,
  },
] as const;

const ORIGIN = [
  {
    when: "2017",
    text: "Un accidente dejó una luxación de rodilla y una fractura del pie. Vinieron cirugías, luxaciones que volvían y una recuperación que no llegó.",
  },
  {
    when: "El trámite",
    text: "La pensión de invalidez fue denegada. En el acta faltaban diagnósticos, aparecían fechas que no existían y datos que nunca se declararon.",
  },
  {
    when: "El trabajo",
    text: "La desvincularon estando con licencia. Consultaron a la Contraloría. La respuesta no resolvió su caso.",
  },
  {
    when: "Después",
    text: "Pasaron años. Estudió, se hizo perito y armó Peritajes Médicos Maule para que otra persona no tenga que explicar su historia desde cero.",
  },
] as const;

function useTheme() {
  const [theme, setTheme] = useState<"light" | "dark">("light");

  useEffect(() => {
    setTheme(document.documentElement.dataset.theme === "dark" ? "dark" : "light");
  }, []);

  function toggle() {
    const next = theme === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    try {
      localStorage.setItem("theme", next);
    } catch {
      /* ignore private mode */
    }
    setTheme(next);
  }

  return { theme, toggle };
}

export function BioPage() {
  const { theme, toggle } = useTheme();
  const dark = theme === "dark";

  return (
    <main className="min-h-dvh bg-bg text-fg">
      <div className="mx-auto flex w-full max-w-lg flex-col px-5 pt-5 pb-14">
        <div className="flex items-center justify-between gap-3">
          <p className="text-xs font-semibold tracking-widest text-muted uppercase">
            Región del Maule
          </p>
          <button
            type="button"
            onClick={toggle}
            aria-pressed={dark}
            aria-label={dark ? "Cambiar a tema claro" : "Cambiar a tema oscuro"}
            className="inline-flex size-11 shrink-0 items-center justify-center rounded-full border border-border bg-surface text-fg transition duration-200 hover:-translate-y-0.5 hover:border-primary"
          >
            {dark ? <Sun className="size-5" strokeWidth={1.75} /> : <Moon className="size-5" strokeWidth={1.75} />}
          </button>
        </div>

        <header className="motion-rise mt-6 animate-rise">
          <div className="flex items-center gap-4">
            <span
              className="inline-flex size-16 shrink-0 items-center justify-center rounded-full border border-accent/50 bg-primary font-display text-xl text-primary-fg"
              aria-hidden="true"
            >
              PG
            </span>
            <div>
              <p className="font-display text-2xl leading-tight text-fg">Paola González</p>
              <p className="mt-1 text-sm leading-snug text-muted">
                Matrona y perito. Creadora de Peritajes Médicos Maule.
              </p>
            </div>
          </div>

          <p className="mt-8 text-sm font-semibold text-accent">Si el sistema ya te dijo que no</p>
          <h1 className="mt-2 font-display text-4xl leading-tight font-medium text-balance text-fg">
            Aquí partimos por creerte.
          </h1>
          <p className="mt-4 text-lg leading-relaxed text-pretty text-fg">
            Esta iniciativa no nació en una oficina. Nació de una pensión de invalidez,
            una licencia y un expediente que no contaban lo que realmente había pasado.
          </p>
        </header>

        <div className="mt-6 flex flex-col gap-3">
          <a
            href="#ayuda"
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-primary px-5 py-3 text-center text-base font-semibold text-primary-fg transition duration-200 hover:-translate-y-0.5"
          >
            Ver en qué te podemos ayudar
          </a>
          <a
            href="#origen"
            className="inline-flex min-h-12 items-center justify-center rounded-full border border-border bg-surface px-5 py-3 text-center text-base font-semibold text-fg transition duration-200 hover:-translate-y-0.5 hover:border-primary"
          >
            Leer por qué existe
          </a>
        </div>

        <figure className="mt-8 rounded-card border border-border border-l-4 border-l-accent bg-surface px-5 py-5">
          <blockquote className="font-display text-xl leading-snug text-pretty text-fg">
            “Y tú qué sabes. Una matrona.” No me enojo. Lo entiendo. Porque no me lo
            contaron: lo viví en carne propia.
          </blockquote>
          <figcaption className="mt-3 text-sm text-muted">Paola González</figcaption>
        </figure>

        <section id="ayuda" className="mt-12 scroll-mt-6">
          <h2 className="font-display text-3xl leading-tight text-fg">Si llegaste buscando ayuda</h2>
          <p className="mt-3 text-base leading-relaxed text-pretty text-muted">
            Estos son los temas por los que existe la empresa. No hace falta llegar con el
            lenguaje correcto. Basta con lo que te pasó.
          </p>
          <ul className="mt-5 flex flex-col gap-3">
            {HELP.map((item) => (
              <li key={item.title} className="rounded-card border border-border bg-surface p-4">
                <div className="flex items-start gap-3">
                  <span className="inline-flex size-10 shrink-0 items-center justify-center rounded-full bg-bg text-primary">
                    <item.icon className="size-5" strokeWidth={1.75} aria-hidden="true" />
                  </span>
                  <div>
                    <h3 className="text-base font-semibold text-fg">{item.title}</h3>
                    <p className="mt-1 text-sm leading-relaxed text-muted">{item.text}</p>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </section>

        <section id="forma" className="mt-12 scroll-mt-6">
          <h2 className="font-display text-3xl leading-tight text-fg">Cómo se trabaja</h2>
          <ul className="mt-5 flex flex-col gap-5">
            {WAY.map((item) => (
              <li key={item.title} className="flex gap-3">
                <item.icon className="mt-0.5 size-5 shrink-0 text-accent" strokeWidth={1.75} aria-hidden="true" />
                <div>
                  <h3 className="font-semibold text-fg">{item.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-muted">{item.text}</p>
                </div>
              </li>
            ))}
          </ul>
          <p className="mt-5 text-sm leading-relaxed text-pretty text-fg">
            El análisis es claro, riguroso y sustentado en evidencia. Sirve para defender a
            una persona en un proceso judicial, previsional o administrativo. No reemplaza
            una promesa de fallo: la ética también es decir lo que el caso sí puede sostener.
          </p>
        </section>

        <section id="origen" className="mt-12 scroll-mt-6">
          <p className="text-sm font-semibold text-accent">La base</p>
          <h2 className="mt-1 font-display text-3xl leading-tight text-fg">De dónde sale todo esto</h2>
          <p className="mt-3 text-base leading-relaxed text-pretty text-fg">
            Paola es matrona. En 2016 cambió de trabajo. El 10 de febrero de 2017 tuvo un
            accidente. Lo que vino después —el desgaste, la incertidumbre y un trámite que
            no la vio— es la razón de esta empresa, no un relato de marketing.
          </p>
          <ol className="mt-6 flex flex-col gap-0">
            {ORIGIN.map((step, index) => (
              <li key={step.when} className="flex gap-3">
                <div className="flex w-16 shrink-0 flex-col items-center">
                  <span className="mt-1 size-2.5 shrink-0 rounded-full bg-accent" aria-hidden="true" />
                  {index < ORIGIN.length - 1 ? (
                    <span className="mt-1 w-px flex-1 bg-border" aria-hidden="true" />
                  ) : null}
                </div>
                <div className={index < ORIGIN.length - 1 ? "pb-6" : ""}>
                  <p className="text-sm font-semibold text-accent">{step.when}</p>
                  <p className="mt-1 text-sm leading-relaxed text-fg">{step.text}</p>
                </div>
              </li>
            ))}
          </ol>
          <a
            href={REEL}
            target="_blank"
            rel="noopener noreferrer"
            className="group mt-6 flex min-h-14 items-center gap-3 rounded-card border border-border bg-surface px-4 py-3 transition duration-200 hover:-translate-y-0.5 hover:border-primary"
          >
            <span className="inline-flex size-10 shrink-0 items-center justify-center rounded-full bg-bg text-primary">
              <Instagram className="size-5" strokeWidth={1.75} aria-hidden="true" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block font-semibold text-fg">Escuchar el testimonio</span>
              <span className="mt-0.5 block text-sm text-muted">
                La comisión donde contó el caso, en sus palabras
              </span>
            </span>
            <ArrowUpRight
              className="size-4 shrink-0 transition duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
              strokeWidth={1.75}
              aria-hidden="true"
            />
          </a>
        </section>

        <section id="contacto" className="mt-12 scroll-mt-6 rounded-card bg-primary px-5 py-6 text-primary-fg">
          <h2 className="font-display text-3xl leading-tight">Si quieres que vean tu caso</h2>
          <p className="mt-3 text-base leading-relaxed text-pretty text-primary-fg/85">
            Cuéntalo con tus palabras. La vía de contacto publicada está en el sitio de
            Peritajes Médicos Maule. De este lado ya se sabe lo que pesa llegar hasta aquí.
          </p>
          <a
            href={SITE}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-5 inline-flex min-h-12 items-center gap-2 rounded-full bg-bg px-5 py-3 text-base font-semibold text-fg transition duration-200 hover:-translate-y-0.5"
          >
            Ir a contacto
            <ArrowUpRight className="size-4" strokeWidth={1.75} aria-hidden="true" />
          </a>
        </section>

        <div className="mt-8 flex items-center justify-center gap-3">
          <a
            href={SITE}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Sitio web de Peritajes Médicos Maule"
            className="inline-flex size-11 items-center justify-center rounded-full border border-border bg-surface text-primary transition duration-200 hover:-translate-y-0.5 hover:border-primary"
          >
            <Globe className="size-5" strokeWidth={1.75} />
          </a>
          <a
            href={INSTAGRAM}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Instagram de Peritajes Médicos Maule"
            className="inline-flex size-11 items-center justify-center rounded-full border border-border bg-surface text-primary transition duration-200 hover:-translate-y-0.5 hover:border-primary"
          >
            <Instagram className="size-5" strokeWidth={1.75} />
          </a>
        </div>

        <footer className="mt-8 text-center text-sm leading-relaxed text-muted">
          <p>Peritajes Médicos Maule</p>
          <a
            href={SITE}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-1 inline-block underline decoration-border underline-offset-4 transition duration-200 hover:text-fg"
          >
            peritajesmedicos.cl
          </a>
        </footer>
      </div>
    </main>
  );
}
