import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ShieldCheck, c as Instagram, d as FileSearch, f as ArrowUpRight, i as Stethoscope, l as HeartHandshake, o as Scale, r as Sun, s as Moon, t as Users, u as Globe } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DP340BaK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SITE = "https://www.peritajesmedicos.cl/";
var REEL = "https://www.instagram.com/reel/DeKBLDeRHFz/";
var INSTAGRAM = "https://www.instagram.com/peritajes_medicosmaule/";
var HELP = [
	{
		title: "Pensión de invalidez",
		text: "Comisiones, AFP y actas que omiten diagnósticos, fechas o el daño real. Leemos el expediente como quien ya vio uno salir mal.",
		icon: Scale
	},
	{
		title: "Licencias médicas",
		text: "Desvinculaciones en plena licencia, licencias impagas y la sensación de tener que demostrar que el dolor existe.",
		icon: FileSearch
	},
	{
		title: "Negligencia médica",
		text: "Cuando faltó la lex artis: no pidieron el examen, no miraron la ficha, o el papel no coincide con lo que te operaron.",
		icon: Stethoscope
	},
	{
		title: "Trámites que no se entienden",
		text: "Procesos judiciales, previsionales y administrativos. El informe tiene que ser claro para ti y sostenible ante quien decide.",
		icon: ShieldCheck
	}
];
var WAY = [
	{
		title: "Ética antes que el resultado",
		text: "El requisito del equipo es una ética inquebrantable. El informe dice lo que la evidencia sostiene, no lo que conviene oír.",
		icon: ShieldCheck
	},
	{
		title: "Un equipo, no una sola voz",
		text: "Médicos de distintas disciplinas. El caso no queda en una impresión ni en una radiografía que no muestra el tejido blando.",
		icon: Users
	},
	{
		title: "Cercanía, sin chamullo",
		text: "Acompañamiento personal y humano. Si llegas con rabia, se entiende. También se entendió desde este lado.",
		icon: HeartHandshake
	}
];
var ORIGIN = [
	{
		when: "2017",
		text: "Un accidente dejó una luxación de rodilla y una fractura del pie. Vinieron cirugías, luxaciones que volvían y una recuperación que no llegó."
	},
	{
		when: "El trámite",
		text: "La pensión de invalidez fue denegada. En el acta faltaban diagnósticos, aparecían fechas que no existían y datos que nunca se declararon."
	},
	{
		when: "El trabajo",
		text: "La desvincularon estando con licencia. Consultaron a la Contraloría. La respuesta no resolvió su caso."
	},
	{
		when: "Después",
		text: "Pasaron años. Estudió, se hizo perito y armó Peritajes Médicos Maule para que otra persona no tenga que explicar su historia desde cero."
	}
];
function useTheme() {
	const [theme, setTheme] = (0, import_react.useState)("light");
	(0, import_react.useEffect)(() => {
		setTheme(document.documentElement.dataset.theme === "dark" ? "dark" : "light");
	}, []);
	function toggle() {
		const next = theme === "dark" ? "light" : "dark";
		document.documentElement.dataset.theme = next;
		try {
			localStorage.setItem("theme", next);
		} catch {}
		setTheme(next);
	}
	return {
		theme,
		toggle
	};
}
function BioPage() {
	const { theme, toggle } = useTheme();
	const dark = theme === "dark";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-dvh bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-lg flex-col px-5 pt-5 pb-14",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-widest text-muted uppercase",
						children: "Región del Maule"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: toggle,
						"aria-pressed": dark,
						"aria-label": dark ? "Cambiar a tema claro" : "Cambiar a tema oscuro",
						className: "inline-flex size-11 shrink-0 items-center justify-center rounded-full border border-border bg-surface text-fg transition duration-200 hover:-translate-y-0.5 hover:border-primary",
						children: dark ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {
							className: "size-5",
							strokeWidth: 1.75
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {
							className: "size-5",
							strokeWidth: 1.75
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "motion-rise mt-6 animate-rise",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "inline-flex size-16 shrink-0 items-center justify-center rounded-full border border-accent/50 bg-primary font-display text-xl text-primary-fg",
								"aria-hidden": "true",
								children: "PG"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl leading-tight text-fg",
								children: "Paola González"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm leading-snug text-muted",
								children: "Matrona y perito. Creadora de Peritajes Médicos Maule."
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 text-sm font-semibold text-accent",
							children: "Si el sistema ya te dijo que no"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-display text-4xl leading-tight font-medium text-balance text-fg",
							children: "Aquí partimos por creerte."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-lg leading-relaxed text-pretty text-fg",
							children: "Esta iniciativa no nació en una oficina. Nació de una pensión de invalidez, una licencia y un expediente que no contaban lo que realmente había pasado."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#ayuda",
						className: "inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-primary px-5 py-3 text-center text-base font-semibold text-primary-fg transition duration-200 hover:-translate-y-0.5",
						children: "Ver en qué te podemos ayudar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#origen",
						className: "inline-flex min-h-12 items-center justify-center rounded-full border border-border bg-surface px-5 py-3 text-center text-base font-semibold text-fg transition duration-200 hover:-translate-y-0.5 hover:border-primary",
						children: "Leer por qué existe"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
					className: "mt-8 rounded-card border border-border border-l-4 border-l-accent bg-surface px-5 py-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
						className: "font-display text-xl leading-snug text-pretty text-fg",
						children: "“Y tú qué sabes. Una matrona.” No me enojo. Lo entiendo. Porque no me lo contaron: lo viví en carne propia."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
						className: "mt-3 text-sm text-muted",
						children: "Paola González"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "ayuda",
					className: "mt-12 scroll-mt-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl leading-tight text-fg",
							children: "Si llegaste buscando ayuda"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-base leading-relaxed text-pretty text-muted",
							children: "Estos son los temas por los que existe la empresa. No hace falta llegar con el lenguaje correcto. Basta con lo que te pasó."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-5 flex flex-col gap-3",
							children: HELP.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "rounded-card border border-border bg-surface p-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "inline-flex size-10 shrink-0 items-center justify-center rounded-full bg-bg text-primary",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
											className: "size-5",
											strokeWidth: 1.75,
											"aria-hidden": "true"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-base font-semibold text-fg",
										children: item.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm leading-relaxed text-muted",
										children: item.text
									})] })]
								})
							}, item.title))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "forma",
					className: "mt-12 scroll-mt-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl leading-tight text-fg",
							children: "Cómo se trabaja"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-5 flex flex-col gap-5",
							children: WAY.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
									className: "mt-0.5 size-5 shrink-0 text-accent",
									strokeWidth: 1.75,
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-semibold text-fg",
									children: item.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm leading-relaxed text-muted",
									children: item.text
								})] })]
							}, item.title))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-sm leading-relaxed text-pretty text-fg",
							children: "El análisis es claro, riguroso y sustentado en evidencia. Sirve para defender a una persona en un proceso judicial, previsional o administrativo. No reemplaza una promesa de fallo: la ética también es decir lo que el caso sí puede sostener."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "origen",
					className: "mt-12 scroll-mt-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold text-accent",
							children: "La base"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 font-display text-3xl leading-tight text-fg",
							children: "De dónde sale todo esto"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-base leading-relaxed text-pretty text-fg",
							children: "Paola es matrona. En 2016 cambió de trabajo. El 10 de febrero de 2017 tuvo un accidente. Lo que vino después —el desgaste, la incertidumbre y un trámite que no la vio— es la razón de esta empresa, no un relato de marketing."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-6 flex flex-col gap-0",
							children: ORIGIN.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex w-16 shrink-0 flex-col items-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1 size-2.5 shrink-0 rounded-full bg-accent",
										"aria-hidden": "true"
									}), index < ORIGIN.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1 w-px flex-1 bg-border",
										"aria-hidden": "true"
									}) : null]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: index < ORIGIN.length - 1 ? "pb-6" : "",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold text-accent",
										children: step.when
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm leading-relaxed text-fg",
										children: step.text
									})]
								})]
							}, step.when))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: REEL,
							target: "_blank",
							rel: "noopener noreferrer",
							className: "group mt-6 flex min-h-14 items-center gap-3 rounded-card border border-border bg-surface px-4 py-3 transition duration-200 hover:-translate-y-0.5 hover:border-primary",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "inline-flex size-10 shrink-0 items-center justify-center rounded-full bg-bg text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instagram, {
										className: "size-5",
										strokeWidth: 1.75,
										"aria-hidden": "true"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block font-semibold text-fg",
										children: "Escuchar el testimonio"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-0.5 block text-sm text-muted",
										children: "La comisión donde contó el caso, en sus palabras"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
									className: "size-4 shrink-0 transition duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5",
									strokeWidth: 1.75,
									"aria-hidden": "true"
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "contacto",
					className: "mt-12 scroll-mt-6 rounded-card bg-primary px-5 py-6 text-primary-fg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl leading-tight",
							children: "Si quieres que vean tu caso"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-base leading-relaxed text-pretty text-primary-fg/85",
							children: "Cuéntalo con tus palabras. La vía de contacto publicada está en el sitio de Peritajes Médicos Maule. De este lado ya se sabe lo que pesa llegar hasta aquí."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: SITE,
							target: "_blank",
							rel: "noopener noreferrer",
							className: "mt-5 inline-flex min-h-12 items-center gap-2 rounded-full bg-bg px-5 py-3 text-base font-semibold text-fg transition duration-200 hover:-translate-y-0.5",
							children: ["Ir a contacto", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
								className: "size-4",
								strokeWidth: 1.75,
								"aria-hidden": "true"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex items-center justify-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: SITE,
						target: "_blank",
						rel: "noopener noreferrer",
						"aria-label": "Sitio web de Peritajes Médicos Maule",
						className: "inline-flex size-11 items-center justify-center rounded-full border border-border bg-surface text-primary transition duration-200 hover:-translate-y-0.5 hover:border-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, {
							className: "size-5",
							strokeWidth: 1.75
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: INSTAGRAM,
						target: "_blank",
						rel: "noopener noreferrer",
						"aria-label": "Instagram de Peritajes Médicos Maule",
						className: "inline-flex size-11 items-center justify-center rounded-full border border-border bg-surface text-primary transition duration-200 hover:-translate-y-0.5 hover:border-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instagram, {
							className: "size-5",
							strokeWidth: 1.75
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "mt-8 text-center text-sm leading-relaxed text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Peritajes Médicos Maule" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: SITE,
						target: "_blank",
						rel: "noopener noreferrer",
						className: "mt-1 inline-block underline decoration-border underline-offset-4 transition duration-200 hover:text-fg",
						children: "peritajesmedicos.cl"
					})]
				})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BioPage, {});
}
//#endregion
export { Home as component };
